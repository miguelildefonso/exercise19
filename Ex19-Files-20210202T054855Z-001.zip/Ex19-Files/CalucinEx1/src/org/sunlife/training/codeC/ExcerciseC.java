package org.sunlife.training.codeC;

public class ExcerciseC {

	public static void main(String[] args) {
		
		sentenceOne();
		sentenceTwo();
		
	}
	
	
	public static void sentenceOne() {
		
		System.out.println("A well-formed Java program has a main");
		System.out.println("method with { and } braces.");
	}
	
	
	public static void sentenceTwo() {
		
		System.out.println("A system.out.println statement has ( and )");
		System.out.println("and usually a String that starts and ends");
		System.out.println("with a 'character. (But we type \' instead!)");
	}
}
