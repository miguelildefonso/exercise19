package org.sunlife.training.codeB;

public class GiveAdvice {
	public static void main(String[] args) {
		
		sentenceOne();
		System.out.println();
		sentenceTwo();
	}
	
	
	public static void sentenceOne() {
		System.out.println("Programs can be easy or difficult "
				+ "to read, depending upon their format.");
	}
	
	
	public static void sentenceTwo() {
		
		System.out.print("'Everyone including yourself, will be "
		        + "happier if you choose to format your " + "Programs.");
	}
}
