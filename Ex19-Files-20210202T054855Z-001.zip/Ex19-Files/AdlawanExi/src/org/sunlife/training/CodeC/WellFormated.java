package org.sunlife.training.CodeC;

public class WellFormated {

	public static void main(String[] args) {
		
		System.out.println("A well-formed Java program has main"+"\n"
							+ "method with { and } braces."+"\n"
							+ "A System.out.println statemnt has ( and )"+"\n"
							+ "and usually a String that starts and ends"+"\n"
							+ "with a \"character. (but we type \\\" instead!)");
	}

}
